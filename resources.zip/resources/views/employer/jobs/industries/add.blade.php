@extends('layouts.default')

@section('content')
Halo
@endsection
