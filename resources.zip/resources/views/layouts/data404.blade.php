<div class="row py-5">
    <div class="container py-5">
        <div class="p-5 text-center">
            <i class="ki-duotone ki-delete-files text-danger fs-5x mb-5">
                <span class="path1"></span>
                <span class="path2"></span>
            </i>
            <br>
            <b class="fs-3">Data Tidak Ditemukan</b>
        </div>
    </div>
</div>
