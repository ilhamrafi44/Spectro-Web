<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\JobsCategory;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JobsCategoryController extends Controller
{
    public function index(Request $request)
    {

        $query = JobsCategory::query();

        $queryParams = $request->query();

        if ($request->filled('name')) {
            $query->where('name', 'like', '%' . $request->input('name') . '%');
        }

        $orderBy = 'created_at';
        $direction = 'asc'; // Default direction

        if ($request->filled('direction') && in_array($request->input('direction'), ['asc', 'desc'])) {
            $direction = $request->input('direction');
        }

        $query->orderBy($orderBy, $direction);

        $perPage = 10;

        if ($request->has('per_page')) {
            $perPage = $request->input('per_page');
        }

        $results = $query->paginate($perPage)->appends($queryParams);

        return view('employer.category', [
            "page_name" => "Job Category List",
            "data" => $results
        ]);
    }

    public function store(Request $request)
    {
        $data = new JobsCategory();
        $data->name = $request->name;
        $data->created_by = Auth::user()->id;
        $saved = $data->save();
        if ($saved) {
            return redirect()->back()->with('message', 'Category Berhasil Ditambah');
        }
        return redirect()->back()->with('error', 'Category Berhasil Ditambah');
    }

    public function destroy(string $id)
    {
        $Category = JobsCategory::where('id', $id)->delete();
        if ($Category) {
            return redirect()->back()->with('message', 'Data berhasil dihapus');
        } else {
            return redirect()->back()->with('error', 'Data gagal dihapus');
        }
    }

    public function update(Request $request)
    {
        $JobsCategory = JobsCategory::findOrFail($request->id);
        $JobsCategory->created_by = Auth::user()->id;
        $JobsCategory->name = $request->name;
        $update = $JobsCategory->update();

        if ($update) {
            return redirect()->back()->with('message', 'Category Berhasil Diubah');
        }
        return redirect()->back()->with('error', 'Category Berhasil Diubah');

    }

}
